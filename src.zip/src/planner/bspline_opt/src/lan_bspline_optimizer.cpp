
#include "bspline_opt/lan_bspline_optimizer.h"

using namespace std;

namespace ugv_planner
{

    LanBsplineOptimizer::LanBsplineOptimizer(){
        order           = 3;
        //w_smothness     = 1000.0;
        //w_feasibility   = 0.01;
        w_smothness     = 1.0;
        w_feasibility   = 0.1;
        w_collision     = 0.5;
        w_collision_t   = w_collision;
        sf              = 0.2;
        max_vel         = 2.0;
        max_acc         = 1.0;
        }
    LanBsplineOptimizer::~LanBsplineOptimizer(){}

    void LanBsplineOptimizer::setCollisionInfo(vector<CollisionPair> collision_gradinfo)
    {
        this -> collision_gradinfo = collision_gradinfo;
    }

    void LanBsplineOptimizer::setOriBspline(UniformBspline bspline)
    {
        original = bspline;
        Eigen::MatrixXd ctrl_pts;
        ctrl_pts = bspline.get_control_points();
        this -> initControlPoints(ctrl_pts);
        bspline_interval = bspline.getInterval();
    }

    void LanBsplineOptimizer::initControlPoints(Eigen::MatrixXd &init_points)
    {
        cps.clearance = 0.5;
        cps.resize(init_points.cols());
        cps.points = init_points;
    }

    void LanBsplineOptimizer::calcSaftyCost( const Eigen::MatrixXd &q, double &cost, Eigen::MatrixXd &gradient)
    {
        cost = 0.0;
        double tem_cost;
        Eigen::Vector3d q_i;
        Eigen::Vector3d q_su;
        double d;     //di,j
        double c;
        CollisionPair cp;
        for(int i = 0 ; i < collision_gradinfo.size(); i++)
        {
            cp   = collision_gradinfo[i];
            //q_i  = q.col(cp.i);
            q_i  = cp.q_i;
            q_su = cp.surface_points_on_obstacle[0];

            d    = (q_i - q_su).dot(cp.v);
            c    = sf - d;

            if(c <= 0)
            {
                cost += 0;
                gradient.col(cp.i) += 0 * cp.v;
            }
            else if(c <= sf ) 
            { 
                cost += pow(c,3);
                gradient.col(cp.i) += -3 * pow(c,2) * cp.v;
            }
            else 
            {
                cost += 3*( sf*pow(c,2) - pow(sf,2)*c + pow(sf,3) );
                gradient.col(cp.i) += (3 * pow(sf,2) - 6 *sf)* cp.v;
            }

        }
    }

    void LanBsplineOptimizer::calcFeasibilityCost(  const Eigen::MatrixXd &q, double &cost,
                                                    Eigen::MatrixXd &gradient)
    {
        cost = 0.0;
        double demarcation = 1.0; // 1m/s, 1m/s/s
        double ar = 3 * demarcation, br = -3 * pow(demarcation, 2), cr = pow(demarcation, 3);
        double al = ar, bl = -br, cl = cr;

        /* abbreviation */
        double ts, ts_inv2, ts_inv3;
        ts = bspline_interval;
        ts_inv2 = 1 / ts / ts;
        ts_inv3 = 1 / ts / ts / ts;

        /* velocity feasibility */
        for (int i = 0; i < q.cols() - 1; i++)
        {
            Eigen::Vector3d vi = (q.col(i + 1) - q.col(i)) / ts;

            for (int j = 0; j < 2; j++)
            {
                if (vi(j) > max_vel + demarcation)
                {
                    double diff = vi(j) - max_vel;
                    cost += (ar * diff * diff + br * diff + cr) * ts_inv3; // multiply ts_inv3 to make vel and acc has similar magnitude

                    double grad = (2.0 * ar * diff + br) / ts * ts_inv3;
                    gradient(j, i + 0) += -grad;
                    gradient(j, i + 1) += grad;
                }
                else if (vi(j) > max_vel)
                {
                    double diff = vi(j) - max_vel;
                    cost += pow(diff, 3) * ts_inv3;
                    double grad = 3 * diff * diff / ts * ts_inv3;
                    gradient(j, i + 0) += -grad;
                    gradient(j, i + 1) += grad;
                }
                else if (vi(j) < -(max_vel + demarcation))
                {
                    double diff = vi(j) + max_vel;
                    cost += (al * diff * diff + bl * diff + cl) * ts_inv3;

                    double grad = (2.0 * al * diff + bl) / ts * ts_inv3;
                    gradient(j, i + 0) += -grad;
                    gradient(j, i + 1) += grad;
                }
                else if (vi(j) < -max_vel)
                {
                    double diff = vi(j) + max_vel;
                    cost += -pow(diff, 3) * ts_inv3;

                    double grad = -3 * diff * diff / ts * ts_inv3;
                    gradient(j, i + 0) += -grad;
                    gradient(j, i + 1) += grad;
                }
                else
                {
                /* nothing happened */
                }
            }
        }

        /* acceleration feasibility */
        for (int i = 0; i < q.cols() - 2; i++)
        {
            Eigen::Vector3d ai = (q.col(i + 2) - 2 * q.col(i + 1) + q.col(i)) * ts_inv2;

            for (int j = 0; j < 2; j++)
            {
                if (ai(j) > max_acc + demarcation)
                {
                    double diff = ai(j) - max_acc;
                    cost += ar * diff * diff + br * diff + cr;

                    double grad = (2.0 * ar * diff + br) * ts_inv2;
                    gradient(j, i + 0) += grad;
                    gradient(j, i + 1) += -2 * grad;
                    gradient(j, i + 2) += grad;
                }
                else if (ai(j) > max_acc)
                {
                    double diff = ai(j) - max_acc;
                    cost += pow(diff, 3);

                    double grad = 3 * diff * diff * ts_inv2;
                    gradient(j, i + 0) += grad;
                    gradient(j, i + 1) += -2 * grad;
                    gradient(j, i + 2) += grad;
                }
                else if (ai(j) < -(max_acc + demarcation))
                {
                    double diff = ai(j) + max_acc;
                    cost += al * diff * diff + bl * diff + cl;

                    double grad = (2.0 * al * diff + bl) * ts_inv2;
                    gradient(j, i + 0) += grad;
                    gradient(j, i + 1) += -2 * grad;
                    gradient(j, i + 2) += grad;
                }
                else if (ai(j) < -max_acc)
                {
                    double diff = ai(j) + max_acc;
                    cost += -pow(diff, 3);

                    double grad = -3 * diff * diff * ts_inv2;
                    gradient(j, i + 0) += grad;
                    gradient(j, i + 1) += -2 * grad;
                    gradient(j, i + 2) += grad;
                }
                else
                {
                /* nothing happened */
                }
            }
        }
    }


    void LanBsplineOptimizer::calcSmoothnessCost(const Eigen::MatrixXd &q, double &cost,
                                                Eigen::MatrixXd &gradient, bool falg_use_jerk /* = true*/)
    {
        cost = 0.0;
        if (falg_use_jerk)
        {
            Eigen::Vector3d jerk, temp_j;
            for (int i = 0; i < q.cols() - 3; i++)
            {
                /* evaluate jerk */
                jerk = q.col(i + 3) - 3 * q.col(i + 2) + 3 * q.col(i + 1) - q.col(i);
                cost += jerk.squaredNorm();
                temp_j = 2.0 * jerk;
                /* jerk gradient */
                gradient.col(i + 0) += -temp_j;
                gradient.col(i + 1) += 3.0 * temp_j;
                gradient.col(i + 2) += -3.0 * temp_j;
                gradient.col(i + 3) += temp_j;
            }
        }
        else
        {
            Eigen::Vector3d acc, temp_acc;

            for (int i = 0; i < q.cols() - 2; i++)
            {
                /* evaluate acc */
                acc = q.col(i + 2) - 2 * q.col(i + 1) + q.col(i);
                cost += acc.squaredNorm();
                temp_acc = 2.0 * acc;
                /* acc gradient */
                gradient.col(i + 0) += temp_acc;
                gradient.col(i + 1) += -2.0 * temp_acc;
                gradient.col(i + 2) += temp_acc;
            }
        }
    }

    void LanBsplineOptimizer::combineCostRebound(const double *x, double *grad, double &f_combine, const int n)
    {
        w_collision_t = pow(2,iternum) * w_collision;
        memcpy(cps.points.data() + 3 * order, x, n * sizeof(x[0]));
        /* ---------- evaluate cost and gradient ---------- */
        double f_smoothness, f_distance, f_feasibility;

        Eigen::MatrixXd g_smoothness     = Eigen::MatrixXd::Zero(3, cps.size);
        Eigen::MatrixXd g_distance       = Eigen::MatrixXd::Zero(3, cps.size);
        Eigen::MatrixXd g_feasibility    = Eigen::MatrixXd::Zero(3, cps.size);

        calcSmoothnessCost(cps.points, f_smoothness, g_smoothness);
        calcSaftyCost(cps.points, f_distance, g_distance);
        calcFeasibilityCost(cps.points, f_feasibility, g_feasibility);

        f_combine = w_smothness * f_smoothness + w_feasibility * f_feasibility + w_collision_t * f_distance; 

        Eigen::MatrixXd grad_3D = w_smothness * g_smoothness + w_feasibility * g_feasibility +  w_collision_t * g_distance; 
        
        //std::cout << " f_smoothness, f_distance, f_feasibility : "<< f_smoothness<<" , "<<f_distance<< " , "<<f_feasibility<<std::endl;
        //std::cout << " gggg "<< grad_3D <<std::endl;
        //std::cout<<"cost = " <<f_combine <<std::endl;

        memcpy(grad, grad_3D.data() + 3 * order, n * sizeof(grad[0]));
    }

    int LanBsplineOptimizer::earlyExit(void *func_data, const double *x, const double *g, const double fx, const double xnorm, const double gnorm, const double step, int n, int k, int ls)
    {
        LanBsplineOptimizer *opt = reinterpret_cast<LanBsplineOptimizer *>(func_data);
        return (opt->force_stop_type_ == STOP_FOR_ERROR || opt->force_stop_type_ == STOP_FOR_REBOUND);
    }

    double LanBsplineOptimizer::costFunction(void *func_data, const double *x, double *grad, const int n)
    {
        LanBsplineOptimizer *opt = reinterpret_cast<LanBsplineOptimizer *>(func_data);

        double cost;

        opt -> combineCostRebound(x, grad, cost, n);
        //opt->iter_num_ += 1;
        return cost;
    }

    void LanBsplineOptimizer::numericalOptimize(UniformBspline& result_bspline)
    {
        double final_cost;
        double delta_u           = original.getInterval();
        Eigen::MatrixXd ctl_pts  = original.get_control_points();
        int ctl_pts_count        = ctl_pts.cols();
        int var_num              = 2 * (ctl_pts_count - 2*order);

        double q[var_num];
        memcpy(q, ctl_pts.data() + 3 * order , var_num * sizeof(q[0]));

        lbfgs::lbfgs_parameter_t lbfgs_params;
        lbfgs::lbfgs_load_default_parameters(&lbfgs_params);
        lbfgs_params.mem_size = 16;
        lbfgs_params.max_iterations = 500;
        lbfgs_params.g_epsilon = 0.01;
        lbfgs_params.line_search_type = 0;
        lbfgs_params.past = 2;
        lbfgs_params.delta = 1e-15;

        /* ---------- optimize ---------- */
        ros::Time t_before, t_end;
        t_before = ros::Time::now();
        int result = lbfgs::lbfgs_optimize(var_num, q, &final_cost, LanBsplineOptimizer::costFunction, NULL, LanBsplineOptimizer::earlyExit, this, &lbfgs_params);
        t_end = ros::Time::now();

        result_bspline = UniformBspline(cps.points, order, bspline_interval);

        { cout << "[optimizer DEBUG] optimization done, time cost: " <<  (t_end - t_before) << " s | result_num = " << result<< endl;}

    }

    void LanBsplineOptimizer::optimize(UniformBspline& result)
    {
        double delta_u           = original.getInterval();
        Eigen::MatrixXd ctl_pts  = original.get_control_points();
        int ctl_pts_count        = ctl_pts.cols();

        Eigen::VectorXd q(ctl_pts_count * 2);         //the variable for optimization

        /*
        for(int i = 0 ; i < ctl_pts_count; i++)
        {
            q(i)                    = ctl_pts(0,i);
            q(i + ctl_pts_count)    = ctl_pts(1,i);
        }
        */
        //{ cout << "[Lan optimizer DEBUG] " <<1 <<endl;}
        Eigen::MatrixXd C1 = Eigen::MatrixXd::Zero(2 * (ctl_pts_count - 1 ),(ctl_pts_count));
        Eigen::MatrixXd C2 = Eigen::MatrixXd::Zero(2 * (ctl_pts_count - 2 ),(ctl_pts_count - 1));
        Eigen::MatrixXd C3 = Eigen::MatrixXd::Zero(2 * (ctl_pts_count - 3 ),(ctl_pts_count - 2));


        //{ cout << "[Lan optimizer DEBUG] " <<2 <<endl;}
        for(int i = 0; i < (ctl_pts_count - 1) ; i++)
        {
            C1(i,i)                             = -1.0 / delta_u;
            C1(i+(ctl_pts_count - 1), i)        = -1.0 / delta_u;
            C1(i,i+1)                           = 1.0 / delta_u;
            C1(i+(ctl_pts_count - 1), i+1)      = 1.0 / delta_u;
        }

        //{ cout << "[Lan optimizer DEBUG] " <<3 <<endl;}

        for(int i = 0; i < (ctl_pts_count - 2) ; i++)
        {
            C2(i,i)                             = -1.0 / delta_u;
            C2(i+(ctl_pts_count - 2),i)         = -1.0 / delta_u;
            C2(i,i+1)                           = 1.0 / delta_u;
            C2(i+(ctl_pts_count - 2),i+1)       = 1.0 / delta_u;
        }

        //{ cout << "[Lan optimizer DEBUG] " <<4 <<endl;}
        for(int i = 0; i < (ctl_pts_count - 3) ; i++)
        {
            C3(i,i)                             = -1.0 / delta_u;
            C3(i+(ctl_pts_count - 3),i)         = -1.0 / delta_u;
            C3(i,i+1)                           = 1.0 / delta_u;
            C3(i+(ctl_pts_count - 3),i+1)       = 1.0 / delta_u;
        }

        //{ cout << "[Lan optimizer DEBUG] " <<5 <<endl;}
        //cout << "C1" <<endl<<C1<<endl;
        //cout << "C2" <<endl<<C2<<endl;
        //cout << "C3" <<endl<<C3<<endl;

        Eigen::MatrixXd Q = C1.transpose() * C2.transpose() * C3.transpose() * C3 * C2 * C1 + 
                            C1.transpose() * C2.transpose() * C2 * C1;
        // Js = q'Qq;
        
    }


}


