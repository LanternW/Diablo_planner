#ifndef LAN_BSPLINE_OPTIMIZER_H
#define LAN_BSPLINE_OPTIMIZER_H


#include <ros/ros.h>
#include <Eigen/Eigen>
#include "bspline_opt/uniform_bspline.h"
#include "bspline_opt/lbfgs.hpp"

namespace ugv_planner
{

    class CollisionPair
    {
        public:
        int i;                                                    //index of control point : Qi
        vector<Eigen::Vector3d> surface_points_on_obstacle;       //as its name
        Eigen::Vector3d         v;                                //as its name
        Eigen::Vector3d         q_i;                              //Qi 's world cor

    };

    class ControlPoints
    {
    public:
        double clearance;
        int size;
        Eigen::MatrixXd points;
        std::vector<std::vector<Eigen::Vector3d>> base_point; // The point at the statrt of the direction vector (collision point)
        std::vector<std::vector<Eigen::Vector3d>> direction;  // Direction vector, must be normalized.
        std::vector<bool> flag_temp;                          // A flag that used in many places. Initialize it everytime before using it.
        // std::vector<bool> occupancy;

        void resize(const int size_set)
        {
        size = size_set;

        base_point.clear();
        direction.clear();
        flag_temp.clear();
        // occupancy.clear();

        points.resize(3, size_set);
        base_point.resize(size);
        direction.resize(size);
        flag_temp.resize(size);
        // occupancy.resize(size);
        }
    };

    class LanBsplineOptimizer
    {
        public:
            LanBsplineOptimizer();
            ~LanBsplineOptimizer();

            void setOriBspline(UniformBspline bspline);
            void setIternum(int iter){iternum = iter;}
            void setCollisionInfo(vector<CollisionPair> collision_gradinfo);
            void optimize(UniformBspline& result);
            void numericalOptimize(UniformBspline& result_bspline);
            void calcSmoothnessCost( const Eigen::MatrixXd &q, double &cost,
                                     Eigen::MatrixXd &gradient, bool falg_use_jerk = true);
            

            void calcFeasibilityCost( const Eigen::MatrixXd &q, double &cost,
                                      Eigen::MatrixXd &gradient);

            void calcSaftyCost( const Eigen::MatrixXd &q, double &cost,
                                      Eigen::MatrixXd &gradient);

            void initControlPoints(Eigen::MatrixXd &init_points);
            int getOrder(){return order;}
        
        private:
            enum FORCE_STOP_OPTIMIZE_TYPE
            {
                DONT_STOP,
                STOP_FOR_REBOUND,
                STOP_FOR_ERROR
            } force_stop_type_;

            UniformBspline original;
            ControlPoints cps;
            vector<CollisionPair> collision_gradinfo;

            double w_smothness;
            double w_feasibility;
            double w_collision;
            double w_collision_t;
            double sf;

            double max_vel, max_acc;
            double bspline_interval;
            int order;
            int iternum;


            static int earlyExit(void *func_data, const double *x, const double *g, const double fx, const double xnorm, const double gnorm, const double step, int n, int k, int ls);
            static double costFunction(void *func_data, const double *x, double *grad, const int n);
            void combineCostRebound(const double *x, double *grad, double &f_combine, const int n);
    };


}

#endif