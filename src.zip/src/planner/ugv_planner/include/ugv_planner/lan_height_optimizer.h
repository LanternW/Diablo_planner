#ifndef _HEIGHT_GENERATOR_OOQP_H_
#define _HEIGHT_GENERATOR_OOQP_H_

#include <ooqp/QpGenData.h>
#include <ooqp/QpGenVars.h>
#include <ooqp/QpGenResiduals.h>
#include <ooqp/GondzioSolver.h>
#include <ooqp/QpGenSparseMa27.h>

#include <ugv_planner/bezier_base.h>

class lanHeightOptimizer 
{
    private:
        vector<double> h_ctrl_points;

    public:
        lanHeightOptimizer(){}
        ~lanHeightOptimizer(){}

        int heightCurveGeneration( 
        const double max_height,
        const double min_height, 
        vector<double> ceil_heights);

        vector<double> getHeightCps()
        {
            return h_ctrl_points;
        };


};

#endif