#include <ugv_planner/lan_height_optimizer.h>
using namespace std;    
using namespace Eigen;

int lanHeightOptimizer::heightCurveGeneration( 
        const double max_height,
        const double min_height,
        vector<double> ceil_heights);
{   

    const int nx  = ceil_heights.size();

    //const int s1CtrlP_num = nx;

    int equ_con_num = 0;
    int ieq_con_pos_num = nx; // all control points within the polytopes, each face assigned a linear constraint

    // upper and lower bounds for all unknowns x
    double  xupp[nx];    
    char   ixupp[nx];
    double  xlow[nx];
    char   ixlow[nx];

    // stacking all bnounds
    for(int i = 0; i < nx; i++)
    {   
        ixlow[i] = 1;
        ixupp[i] = 1;
        xlow[i]  = min_height;
        xupp[i]  = max_height;
    }


    int my = equ_con_num; // equality constarins

    double b[my];
    for(int i = 0; i < my; i++)
        b[i] = con_eq_bd[i];
   
    int nn_idx  = 0;
    int row_idx = 0;
   
    int nnzA  = 0 ;
    //z = 0

    double dA[nnzA];
    int irowA[nnzA];
    int jcolA[nnzA];

    // linear constraints: hyperplanes; boundary of acceleration and velocity
    const int mz  = nx;

    char iclow[mz];
    char icupp[mz];
    double clow[mz];
    double cupp[mz];
 
    for(int i = 0; i < mz; i++)
    {   
        iclow[i] = 0; 
        icupp[i] = 1;

        clow[i]  = 0;
        cupp[i]  = ceil_heights[i];  //x[i] < height[i]
    }

    // add velocity     constraints on all segments of the trajectory
    // add acceleration constraints on all segments of the trajectory
    // linear constraints, equations
    int nnzC = nx; 
    int irowC[nnzC];
    int jcolC[nnzC];
    double dC[nnzC];


    for(int i = 0; i < nnzC; i++)
    {  
        // C = identity(nx)
        dC[i] = 1;
        irowC[nn_idx]   = i;
        jcolC[nn_idx]   = i; 
    }

    // stack the objective function
    //const int nnzQ = 3 * segment_num * (traj_order + 1) * (traj_order + 2) / 2 ;
    const int nnzQ = 2*nx -1 ;
    int    irowQ[nnzQ]; 
    int    jcolQ[nnzQ];
    double    dQ[nnzQ];

    double  c[nx];

    for(int i = 0; i < nx; i++)
    {
        c[i] = -1.0;
    }

    int idx = 0;
    for( int i = 0; i < nx; i ++ )
    {
        irowQ[idx] = i;   
        jcolQ[idx] = i;  
        dQ[idx]    = 1.0;
        idx ++ ;
    }
    for( int i = 0; i < nx-1; i ++ )
    {
        irowQ[idx] = i;   
        jcolQ[idx] = i+1;  
        dQ[idx]    = -2.0;
        idx ++ ;
    }


    QpGenSparseMa27 * qp 
    = new QpGenSparseMa27( nx, my, mz, nnzQ, nnzA, nnzC );

    QpGenData * prob = (QpGenData * ) qp->copyDataFromSparseTriple(
        c,      irowQ,  nnzQ,   jcolQ,  dQ,
        xlow,   ixlow,  xupp,   ixupp,
        irowA,  nnzA,   jcolA,  dA,     b,
        irowC,  nnzC,   jcolC,  dC,
        clow,   iclow,  cupp,   icupp );

    QpGenVars      * vars  = (QpGenVars *) qp->makeVariables( prob );
    QpGenResiduals * resid = (QpGenResiduals *) qp->makeResiduals( prob );
    GondzioSolver  * s     = new GondzioSolver( qp, prob );
    
    // Turn Off/On the print of the solving process
    // s->monitorSelf();
    int ierr = s->solve(prob, vars, resid);

    if( ierr == 0 ) 
    {
        double d_var[nx];
        vars->x->copyIntoArray(d_var);

        h_ctrl_points.clear();
        for(int i = 0; i < nx; i++ )
        {   
            h_ctrl_points.push_back(d_var[i]);
          
        }   
    } 
    else if( ierr == 3)
        cout << "The program is provably infeasible, check the formulation.\n";
    else if (ierr == 4)
        cout << "The program is very slow in convergence, may have numerical issue.\n";
    else
        cout << "Solver numerical error.\n";
    
    return ierr;
}